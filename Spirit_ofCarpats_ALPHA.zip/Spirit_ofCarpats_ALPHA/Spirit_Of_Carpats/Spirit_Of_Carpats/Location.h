#pragma once
class object_box;
class news_peaper;
class back_ground;
